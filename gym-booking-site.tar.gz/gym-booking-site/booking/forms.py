"""Forms for the booking app."""

from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User
from .models import Booking


class SignUpForm(UserCreationForm):
    """User registration form extending Django's UserCreationForm."""

    email = forms.EmailField(required=False)

    class Meta:
        model = User
        fields = ("username", "email", "password1", "password2")


class BookingForm(forms.ModelForm):
    """Placeholder form for booking; currently unused as booking is handled in view."""

    class Meta:
        model = Booking
        fields: list[str] = []