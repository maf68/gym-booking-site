"""URL configuration for the booking app."""

from django.urls import path
from . import views

app_name = "booking"

urlpatterns = [
    path("", views.home, name="home"),
    path("gym/<int:gym_id>/", views.gym_detail, name="gym_detail"),
    path("signup/", views.signup, name="signup"),
    path("book/<int:timeslot_id>/", views.book_timeslot, name="book_timeslot"),
]