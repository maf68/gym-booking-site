"""Admin registrations for booking app."""

from django.contrib import admin
from .models import Gym, TimeSlot, Booking


@admin.register(Gym)
class GymAdmin(admin.ModelAdmin):
    list_display = ("name",)


@admin.register(TimeSlot)
class TimeSlotAdmin(admin.ModelAdmin):
    list_display = ("gym", "start_time", "end_time")
    list_filter = ("gym",)


@admin.register(Booking)
class BookingAdmin(admin.ModelAdmin):
    list_display = ("user", "timeslot")
    list_filter = ("timeslot__gym",)