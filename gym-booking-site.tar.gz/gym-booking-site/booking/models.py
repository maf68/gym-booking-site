"""Models for the booking app."""

from django.db import models
from django.contrib.auth.models import User


class Gym(models.Model):
    """A fitness gym available for booking."""
    name = models.CharField(max_length=100)

    def __str__(self) -> str:
        return self.name


class TimeSlot(models.Model):
    """A time slot for a specific gym."""
    gym = models.ForeignKey(Gym, on_delete=models.CASCADE, related_name="timeslots")
    start_time = models.DateTimeField()
    end_time = models.DateTimeField()

    def __str__(self) -> str:
        return (
            f"{self.gym.name} - {self.start_time.strftime('%Y-%m-%d %H:%M')}"
            f" to {self.end_time.strftime('%H:%M')}"
        )


class Booking(models.Model):
    """A booking made by a user for a given time slot."""
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name="bookings")
    timeslot = models.ForeignKey(TimeSlot, on_delete=models.CASCADE, related_name="bookings")

    class Meta:
        unique_together = ("timeslot", "user")

    def __str__(self) -> str:
        return f"{self.user.username} booked {self.timeslot}"