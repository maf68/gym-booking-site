"""Views for the booking app."""

from datetime import timedelta
import random

from django.contrib import messages
from django.contrib.auth import login
from django.contrib.auth.decorators import login_required
from django.shortcuts import get_object_or_404, redirect, render
from django.utils import timezone

from .forms import SignUpForm
from .models import Booking, Gym, TimeSlot


def populate_data() -> None:
    """Populate the database with gyms and time slots if empty.

    This helper creates a handful of gyms and 1‑hour time slots over the next 5 days
    from 8:00 to 20:00. It runs on each home request but only inserts data when
    the tables are empty.
    """

    if Gym.objects.exists():
        return

    # sample gym names
    names = [
        "Olympus Gym",
        "Fitness Factory",
        "Powerhouse Fitness",
        "Iron Paradise",
        "Muscle Matrix",
        "FitHub",
        "CoreZone",
        "FlexFit",
    ]
    for name in names:
        gym = Gym.objects.create(name=name)
        # create time slots: next 5 days, 8am-8pm (12 slots per day)
        start = timezone.now().replace(hour=8, minute=0, second=0, microsecond=0)
        for day in range(5):
            day_start = start + timedelta(days=day)
            for hour_offset in range(12):
                st = day_start + timedelta(hours=hour_offset)
                end = st + timedelta(hours=1)
                TimeSlot.objects.create(gym=gym, start_time=st, end_time=end)


def home(request):
    """Homepage: list all available gyms."""
    populate_data()
    gyms = Gym.objects.all()
    return render(request, "home.html", {"gyms": gyms})


def gym_detail(request, gym_id: int):
    """Detail page for a gym showing upcoming time slots and booking buttons."""
    gym = get_object_or_404(Gym, pk=gym_id)
    timeslots = (
        gym.timeslots.filter(start_time__gte=timezone.now())
        .order_by("start_time")
    )
    return render(
        request,
        "gym_detail.html",
        {"gym": gym, "timeslots": timeslots},
    )


def signup(request):
    """Handle user registration via the SignUpForm."""
    if request.method == "POST":
        form = SignUpForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            messages.success(request, "Account created successfully!")
            return redirect("home")
    else:
        form = SignUpForm()
    return render(request, "registration/signup.html", {"form": form})


@login_required
def book_timeslot(request, timeslot_id: int):
    """Book a time slot if it isn't already booked."""
    timeslot = get_object_or_404(TimeSlot, pk=timeslot_id)
    # Check if timeslot already booked
    if Booking.objects.filter(timeslot=timeslot).exists():
        messages.error(request, "This timeslot is already booked.")
        return redirect("gym_detail", gym_id=timeslot.gym.id)
    Booking.objects.create(user=request.user, timeslot=timeslot)
    messages.success(request, "Timeslot booked successfully!")
    return redirect("gym_detail", gym_id=timeslot.gym.id)